<?php

namespace fivefilters\Readability\Nodes\DOM;

use fivefilters\Readability\Nodes\NodeTrait;

class DOMDocumentType extends \DOMDocumentType
{
    use NodeTrait;
}
